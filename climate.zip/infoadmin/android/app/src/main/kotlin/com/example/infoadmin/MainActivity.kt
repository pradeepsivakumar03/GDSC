package com.example.infoadmin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
