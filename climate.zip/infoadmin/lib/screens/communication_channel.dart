import 'dart:math';
import 'dart:developer' as dev;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:swipe_to/swipe_to.dart';
// import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:sizer/sizer.dart';
import 'package:vibration/vibration.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  // bool _isAtLatestMessage = false;
  String? lastSenderId;
  // String? _myname;
  final ScrollController _scrollController = ScrollController(); //
  final FocusNode _messageFocusNode = FocusNode();
  final TextEditingController _messageController = TextEditingController();
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool _isEmojiPickerVisible = false;
  Color kPrimaryColor = const Color.fromARGB(255, 51, 141, 177);
  Color kSecondaryColor = const Color.fromARGB(255, 155, 73, 148);
  Color kTextBlackColor = const Color(0xFF313131);
  Color kTextWhiteColor = const Color(0xFFFFFFFF);
  Color kContainerColor = const Color(0xFF777777);
  Color kOtherColor = const Color(0xFFF4F6F7);
  Color kTextLightColor = const Color(0xFFA5A5A5);
  Color kErrorBorderColor = const Color(0xFFE74C3C);

  getNotificationPermission() async {
    var status = await Permission.notification.status;
    dev.log(status.toString());
    if (status.isDenied) {
      await Permission.notification.request();
    } else if (status.isPermanentlyDenied) {
      await openAppSettings();
    }
  }

  @override
  void initState() {
    super.initState();
    getNotificationPermission();
    // _scrollController.addListener(_scrollListener);
  }

  @override
  void dispose() {
    // _scrollController.removeListener(_scrollListener);
    // _scrollController.dispose();
    super.dispose();
  }

  // void _scrollListener() {
  //   setState(() {
  //     // Check if the user is at the latest message or not
  //     _isAtLatestMessage = _scrollController.offset >=
  //         _scrollController.position.maxScrollExtent - 200;
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.grey[350],
        appBar: AppBar(
          title: const Text('Messages'),
        ),
        body: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () {
            FocusScope.of(context).unfocus();
            hideEmojiPicker();
            setState(() {
              _isEmojiPickerVisible = false;
            });
          },
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: _firestore
                      .collection('chats')
                      .orderBy('time', descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.hasError) {
                      return Center(child: Text(''));
                    }

                    if (!snapshot.hasData || snapshot.data == null) {
                      return const Center(child: CircularProgressIndicator());
                    }

                    final messages = snapshot.data!.docs;

                    return Scrollbar(
                      trackVisibility: true,
                      interactive: true,
                      controller: _scrollController,
                      child: ListView.builder(
                        shrinkWrap: true,
                        controller: _scrollController,
                        reverse: true,
                        itemCount: messages.length,
                        itemBuilder: (context, index) {
                          final messageData =
                              messages[index].data() as Map<String, dynamic>;
                          final messageText = messageData['msg'];
                          final senderId = messageData['uid'];
                          final messageId = snapshot.data!.docs[index].id;
                          final username = messageData['sentBy'];
                          final Timestamp timestamp = messageData['time'];
                          final DateTime dateTime = timestamp.toDate();
                          final time = DateFormat('hh:mm a').format(dateTime);
                          final userId = FirebaseAuth.instance.currentUser!.uid;
                          final repliedMessage = messageData['repliedMessage'];
                          final repliedUsername = messageData['replyusername'];
                          final isMe = userId == senderId;
                          // final getname = messages[index]['replyusername'];
                          // Update lastSenderId for consecutive messages from the same sender
                          if (index == 0 ||
                              senderId != messages[index - 1]['uid']) {
                            lastSenderId = senderId;
                          }

                          return _buildMessageTile(
                            messageText,
                            isMe,
                            username,
                            messageId,
                            repliedMessage,
                            index,
                            messages,
                            senderId,
                            time,
                            repliedUsername,
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
              SizedBox(height: 1.h),
              _buildTextComposer(),
              SizedBox(height: 1.h),
            ],
          ),
        )
        // floatingActionButton: _isAtLatestMessage
        //     ? Padding(
        //         padding: EdgeInsets.only(bottom: 5.5.h, right: 2.w),
        //         child: SizedBox(
        //           height: 8.h,
        //           width: 8.w,
        //           child: FloatingActionButton(
        //             backgroundColor: kPrimaryColor,
        //             onPressed: _scrollToLatestMessage,
        //             mini: true,
        //             child: Icon(
        //               size: 2.h,
        //               Icons.arrow_downward_rounded,
        //               color: Colors.white,
        //             ),
        //           ),
        //         ),
        //       )
        //     : null,
        );
  }

  // void _scrollToLatestMessage() {
  //   _scrollController.animateTo(
  //     _scrollController.position.minScrollExtent,
  //     duration: const Duration(milliseconds: 500),
  //     curve: Curves.easeInOut,
  //   );
  // }

  // void _showEmojiPicker() {
  //   showModalBottomSheet(
  //       context: context,
  //       builder: (BuildContext context) {
  //         return SizedBox(
  //           height: 40.h,
  //           child: EmojiPicker(
  //             onEmojiSelected: (Category? category, Emoji emoji) {
  //               // Do something when emoji is tapped (optional)
  //             },
  //             onBackspacePressed: () {
  //               // Do something when the user taps the backspace button (optional)
  //               // Set it to null to hide the Backspace-Button
  //             },
  //             textEditingController:
  //                 _messageController, // pass here the same [TextEditingController] that is connected to your input field, usually a [TextFormField]
  //             config: Config(
  //               columns: 7,
  //               emojiSizeMax: 32 *
  //                   (foundation.defaultTargetPlatform == TargetPlatform.iOS
  //                       ? 1.30
  //                       : 1.0), // Issue: https://github.com/flutter/flutter/issues/28894
  //               verticalSpacing: 0,
  //               horizontalSpacing: 0,
  //               gridPadding: EdgeInsets.zero,
  //               initCategory: Category.RECENT,
  //               bgColor: const Color(0xFFF2F2F2),
  //               indicatorColor: Colors.blue,
  //               iconColor: Colors.grey,
  //               iconColorSelected: Colors.blue,
  //               backspaceColor: Colors.blue,
  //               skinToneDialogBgColor: Colors.white,
  //               skinToneIndicatorColor: Colors.grey,
  //               enableSkinTones: true,
  //               recentTabBehavior: RecentTabBehavior.RECENT,
  //               recentsLimit: 28,
  //               noRecents: const Text(
  //                 'No Recents',
  //                 style: TextStyle(fontSize: 20, color: Colors.black26),
  //                 textAlign: TextAlign.center,
  //               ), // Needs to be const Widget
  //               loadingIndicator:
  //                   const SizedBox.shrink(), // Needs to be const Widget
  //               tabIndicatorAnimDuration: kTabScrollDuration,
  //               categoryIcons: const CategoryIcons(),
  //               buttonMode: ButtonMode.MATERIAL,
  //             ),
  //           ),
  //         );
  //       });
  // }
  // void _handleReplyAction(String originalMessage, String? originalUsername,
  //     String originalMsgId, String? repliedUsername) {
  //   // Generate the tag for the reply
  //   String tag;
  //   if (originalUsername != null) {
  //     tag = '@$originalUsername: $originalMessage';
  //   } else {
  //     tag = 'You replied to @$repliedUsername: $originalMessage';
  //   }

  // Set the reply tag in the text field
  //   _messageController.text = tag;
  //   _messageController.selection = TextSelection.fromPosition(
  //       TextPosition(offset: _messageController.text.length));
  // }

  Widget _buildTextComposer() {
    return SafeArea(
      bottom: true,
      child: CupertinoTheme(
        data: const CupertinoThemeData(
          primaryColor:
              Colors.blue, // Change this to your desired primary color
        ),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 2.w),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    child: CupertinoTextField(
                      onTap: () {
                        setState(() {
                          _isEmojiPickerVisible = false;
                        });
                      },
                      prefix: IconButton(
                        onPressed: () {
                          // Toggle the visibility of the emoji picker
                          setState(() {
                            _isEmojiPickerVisible = !_isEmojiPickerVisible;
                          });
                          if (_isEmojiPickerVisible) {
                            // When showing the emoji picker, hide the keyboard
                            _messageFocusNode.unfocus();
                          }
                        },
                        icon: Icon(
                          _isEmojiPickerVisible
                              ? Icons.keyboard_outlined
                              : Icons.emoji_emotions,
                          color: kPrimaryColor,
                        ),
                      ),
                      focusNode: _messageFocusNode,
                      controller: _messageController,
                      maxLines: null,
                      textAlign: TextAlign.left,
                      textAlignVertical: TextAlignVertical.center,
                      placeholder: 'Send a message',
                      placeholderStyle: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 10.sp,
                      ),
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: kTextBlackColor,
                      ),
                      decoration: BoxDecoration(
                        color: kOtherColor,
                        borderRadius: BorderRadius.circular(7.w),
                      ),
                      // padding: EdgeInsets.only(
                      //   left: 5.w,
                      //   right: 5.w,
                      //   top: 1.8.h,
                      //   bottom: 1.h,
                      // ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 2.0.w),
                    child: CupertinoButton(
                      alignment: Alignment.center,
                      minSize: 0,
                      padding: EdgeInsets.all(1.4.h),
                      borderRadius: BorderRadius.circular(6.w),
                      color: Colors.green,
                      onPressed: () {
                        if (_messageController.text.trim().isNotEmpty) {
                          _handleSubmitted(_messageController.text);
                        }
                      },
                      child: const Icon(
                        Icons.send,
                        color: CupertinoColors.white,
                      ),
                    ),
                  ),
                ],
              ),
              // Offstage(
              //   // Use Offstage to show/hide the emoji picker
              //   offstage: !_isEmojiPickerVisible,
              //   child: SizedBox(
              //     height: 30.h,
              //     width: double
              //         .infinity, // Set the desired height for the emoji picker
              //     child: EmojiPicker(
              //       onEmojiSelected: (Category? category, Emoji emoji) {
              //         // Do something when emoji is tapped (optional)
              //       },
              //       onBackspacePressed: () {
              //         // Do something when the user taps the backspace button (optional)
              //         // Set it to null to hide the Backspace-Button
              //       },
              //       textEditingController: _messageController,
              //       config: const Config(
              //           // Emoji picker configuration...
              //           ),
              //     ),
              //   ),
              // ),
            ],
          ),
        ),
      ),
    );
  }

  void showEmojiPicker() {
    setState(() {
      _isEmojiPickerVisible = true;
    });
  }

  void hideEmojiPicker() {
    setState(() {
      _isEmojiPickerVisible = false;
    });
  }

  void _handleSubmitted(String text,
      {String? repliedMessage, String? replyusername}) async {
    if (text.trim().isNotEmpty) {
      final user = _auth.currentUser;
      if (user != null) {
        // if(repliedMessage.isNotEmpty && repliedMessage!=null){
        final username = await _getUsername(user.uid);
        // }

        _firestore.collection('chats').doc().set({
          'uid': user.uid,
          'sentBy': username,
          'msg': text,
          'time': DateTime.now(),
          'repliedMessage': repliedMessage,
          'replyusername': replyusername
        });

        _messageController.clear();

        FirebaseMessaging messaging = FirebaseMessaging.instance;

        await messaging.requestPermission(
          alert: true,
          announcement: false,
          badge: true,
          carPlay: false,
          criticalAlert: false,
          provisional: false,
          sound: true,
        );
        messaging.setForegroundNotificationPresentationOptions(
            alert: true, badge: true, sound: true);

        // sendNotify(text);

        // print('User granted permission: ${settings.authorizationStatus}');

        // final recipientToken = await messaging.getToken();
        // print(recipientToken);

        // if (recipientToken != null) {
        //   final notificationData = {
        //     'title': 'New Message',
        //     'body': text,
        //     'click_action': 'FLUTTER_NOTIFICATION_CLICK',
        //   };

        //   try {
        //     if (notificationData.containsKey('title') &&
        //         notificationData.containsKey('body')) {
        //       RemoteMessage(
        //         senderId: username,
        //         notification: RemoteNotification(
        //           android: const AndroidNotification(),
        //           title: notificationData['title'],
        //           body: notificationData['body'],
        //         ),
        //         data: notificationData,
        //       );

        _messageController.clear();
      } else {
        // print('Invalid notification data format.');
        // }
        // } catch (error) {
        // print('Error sending FCM: $error');
        // }
        // }
      }
    }
  }

  // static Future<String> getToken(userId) async {
  //   final FirebaseFirestore db = FirebaseFirestore.instance;

  //   var token;
  //   await db
  //       .collection('users')
  //       .doc(userId)
  //       .collection('tokens')
  //       .get()
  //       .then((snapshot) {
  //     for (var doc in snapshot.docs) {
  //       token = doc['token'];
  //       print(token);
  //     }
  //   });

  //   return token;
  // }

  // Future<void> sendNotify(String msg) async {
  //   List<String> tokens = await retrieveData();

  //   // await Future.delayed(Duration(seconds: 5));

  //   final data = {
  //     "notification": {"body": msg, "title": "New Message"},
  //     "priority": "high",
  //     "data": {
  //       "click_action": "FLUTTER_NOTIFICATION_CLICK",
  //       "id": "1",
  //       "status": "done"
  //     },
  //     "registration_ids": tokens,
  //   };

  //   final headers = {
  //     'content-type': 'application/json',
  //     'Authorization': 'key=$authorizationkey',
  //   };

  //   final response = await http.post(
  //     Uri.parse('https://fcm.googleapis.com/fcm/send'),
  //     body: json.encode(data),
  //     headers: headers,
  //   );

  //   print(response.body);
  // }

  // Future<List<String>> retrieveData() async {
  //   try {
  //     CollectionReference devTokenCollection =
  //         FirebaseFirestore.instance.collection('devtoken');
  //     QuerySnapshot querySnapshot = await devTokenCollection.get();
  //     List<String> tokens = [];

  //     for (var document in querySnapshot.docs) {
  //       Map<String, dynamic> data = document.data() as Map<String, dynamic>;
  //       String token = data['token'] ?? "";
  //       print(token);
  //       tokens.add(token);
  //     }

  //     return tokens;
  //   } catch (e) {
  //     print("Error retrieving data: $e");
  //     return [];
  //   }
  // }

  // static Future<List<String>> retrieveData() async {
  //   try {
  //     // Reference to the "devtoken" collection
  //     CollectionReference devTokenCollection =
  //         FirebaseFirestore.instance.collection('devtoken');

  //     // Get the documents from the collection
  //     QuerySnapshot querySnapshot = await devTokenCollection.get();

  //     // Create a list to store the tokens
  //     List<String> tokens = [];

  //     // Loop through the documents and access the "token" field
  //     for (var document in querySnapshot.docs) {
  //       Map<String, dynamic> data = document.data() as Map<String, dynamic>;
  //       String token = data['token'] ?? "";
  //       print(token);
  //       tokens.add(token); // Add the token to the list
  //     }

  //     return tokens; // Return the list of tokens
  //   } catch (e) {
  //     print("Error retrieving data: $e");
  //     return []; // Return an empty list in case of an error
  //   }
  // }

  // static Future<void> sendNotify(receiver, msg) async {
  //   var token = await retrieveData();

  //   final data = {
  //     "notification": {"body": msg, "title": "New Message"},
  //     "priority": "high",
  //     "data": {
  //       "click_action": "FLUTTER_NOTIFICATION_CLICK",
  //       "id": "1",
  //       "status": "done"
  //     },
  //     "to": token
  //   };
  //   print("tokens: $token");
  //   final headers = {
  //     'content-type': 'application/json',
  //     'Authorization': 'key=$authorizationkey'
  //   };

  //   final response = await http.post(
  //     Uri.parse('https://fcm.googleapis.com/fcm/send'),
  //     body: json.encode(data),
  //     headers: headers,
  //   );
  //   print(response.body);
  // }

  Future<String?> _getUsername(String userId) async {
    final userDoc = await _firestore.collection('users').doc(userId).get();
    return userDoc.data()?['username'] as String?;
  }

  Future<String> _getimg(String userId) async {
    final profiledoc = await _firestore.collection('users').doc(userId).get();
    return profiledoc.data()!['profileimg'];
  }

  Widget _buildMessageTile(
    String message,
    bool isMe,
    String username,
    String msgId,
    String? repliedMessage,
    int index,
    List messages,
    String senderId,
    String time,
    String? repliedUsername,
  ) {
    final avatar = isMe
        ? const SizedBox.shrink()
        : Padding(
            padding: EdgeInsets.only(top: 2.3.h),
            child: FutureBuilder<String>(
              future: _getimg(senderId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  // Return a placeholder or loading widget while waiting for the future to complete
                  return Padding(
                      padding:
                          EdgeInsets.only(top: 2.5.h, left: 2.5.w, right: 1.w),
                      child: CircleAvatar(
                        radius: 4.w,
                        backgroundColor: kPrimaryColor,
                        child: const Icon(Icons.person),
                      ));
                } else if (snapshot.hasError) {
                  // Handle error if needed
                  return CircleAvatar(
                    radius: 4.w,
                    backgroundColor: kPrimaryColor,
                    child: const Icon(Icons.error),
                  );
                } else {
                  // Use the retrieved image URL from the snapshot.data
                  return Padding(
                    padding:
                        EdgeInsets.only(top: 2.5.h, left: 2.5.w, right: 1.w),
                    child: CircleAvatar(
                      radius: 4.w,
                      backgroundColor: kPrimaryColor,
                      backgroundImage: NetworkImage(snapshot.data!),
                    ),
                  );
                }
              },
            ),
          );

    final showUsername = index == messages.length - 1 ||
        (index < messages.length - 1 && messages[index + 1]['uid'] != senderId);

    final chatBubble = showUsername
        ? Padding(
            padding: showUsername
                ? EdgeInsets.only(bottom: isMe ? 0.0.h : 0.5.h, right: 0.w)
                : EdgeInsets.only(bottom: 0.0.h),
            child: ChatBubble(
              elevation: 0.h,
              clipper: isMe
                  ? ChatBubbleClipper4(type: BubbleType.sendBubble)
                  : ChatBubbleClipper4(type: BubbleType.receiverBubble),
              backGroundColor: isMe ? Colors.blue[50] : Colors.white,
              child: Column(
                crossAxisAlignment:
                    isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  if (showUsername)
                    isMe
                        ? SizedBox(
                            width: 0.5.h,
                          )
                        : Text(
                            username,
                            style: TextStyle(
                              color: getUsernameColor(username),
                              fontSize: 10.sp,
                            ),
                            textAlign: TextAlign.left,
                          ),
                  SizedBox(height: 0.5.h),
                  Container(
                    constraints: BoxConstraints(
                        maxWidth: 70.w), // Set your desired max width
                    child: Text(
                      message,
                      style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                            color: kTextBlackColor,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.normal,
                          ),
                      textAlign: isMe ? TextAlign.left : TextAlign.left,
                      softWrap: true,
                      maxLines: 200, // Set the maximum number of lines
                      overflow: TextOverflow.ellipsis, // Overflow behavior
                    ),
                  ),
                  SizedBox(height: 1.h),
                  Text(
                    time,
                    style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                          color: isMe ? Colors.blue[500] : Colors.grey[500],
                          fontSize: 7.sp,
                          fontWeight: FontWeight.normal,
                        ),
                    textAlign: TextAlign.end,
                  )
                ],
              ),
            ),
          )
        : Padding(
            padding: isMe
                ? EdgeInsets.only(right: .0.w, top: 0.0.h)
                : EdgeInsets.only(right: 0.0.w),
            child: Container(
              padding: EdgeInsets.all(1.5.h),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(2.w),
                color: isMe ? Colors.blue[50] : Colors.white,
              ),
              child: Column(
                mainAxisAlignment:
                    isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                children: [
                  Container(
                    constraints: BoxConstraints(
                        maxWidth: 70.w), // Set your desired max width
                    child: Text(
                      message,
                      style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                            color: kTextBlackColor,
                            fontSize: 12.sp,
                            fontWeight: FontWeight.normal,
                          ),
                      textAlign: isMe ? TextAlign.left : TextAlign.left,
                      softWrap: true,
                      maxLines: 200, // Set the maximum number of lines
                      overflow: TextOverflow.ellipsis, // Overflow behavior
                    ),
                  ),
                  const SizedBox(height: 1.5),
                  Text(
                    time,
                    style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                          color: isMe ? Colors.blue[500] : Colors.grey[500],
                          fontSize: 7.sp,
                          fontWeight: FontWeight.normal,
                        ),
                    textAlign: TextAlign.end,
                  )
                ],
              ),
            ),
          );

    // Check if repliedMessage is available and wrap chatBubble with repliedMessageWidget
    final messageContent = repliedMessage != null && repliedUsername != null
        ? showUsername
            ?
            // // Padding(
            // //     padding: EdgeInsets.only(
            // //         left: isMe
            // //             ? 0.0
            // //             : showUsername
            // //                 ? 2.0.w
            // //                 : 0.0,
            // //         right: isMe && showUsername ? 2.w : 0.0),
            // //     child: Container(
            //       constraints: BoxConstraints(minWidth: 6.w),
            //       decoration: BoxDecoration(
            //         color: isMe ? Colors.blue[50] : Colors.white,
            //         borderRadius: BorderRadius.circular(1.5.w),
            //       ),
            //       child:
            ChatBubble(
                backGroundColor: isMe ? Colors.blue[50] : Colors.white,
                clipper: isMe
                    ? ChatBubbleClipper4(type: BubbleType.sendBubble)
                    : ChatBubbleClipper4(type: BubbleType.receiverBubble),
                child: Column(
                  crossAxisAlignment:
                      isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                  children: [
                    // if (repliedUsername != null) // Check for nullability
                    repliedMessageWidget(
                      repliedMessage,
                      senderId,
                      isMe,
                      username,
                      index,
                      messages,
                      repliedUsername,
                      showUsername,
                    ),
                    // Container(
                    //   padding: const EdgeInsets.all(8.0),
                    //   color: isMe ? Colors.blue[50] : Colors.white,
                    //   child:
                    Container(
                      constraints: BoxConstraints(
                          maxWidth: 70.w), // Set your desired max width
                      child: Text(
                        message,
                        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                              color: kTextBlackColor,
                              fontSize: 12.sp,
                              fontWeight: FontWeight.normal,
                            ),
                        textAlign: isMe ? TextAlign.left : TextAlign.left,
                        softWrap: true,
                        maxLines: 200, // Set the maximum number of lines
                        overflow: TextOverflow.ellipsis, // Overflow behavior
                      ),
                    ),
                    // ),
                    const SizedBox(height: 1.5),
                    // Padding(
                    // padding: const EdgeInsets.all(5.0),
                    // child:
                    Text(
                      time,
                      style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                            color: isMe ? Colors.blue[500] : Colors.grey[500],
                            fontSize: 7.sp,
                            fontWeight: FontWeight.normal,
                          ),
                      textAlign: isMe ? TextAlign.start : TextAlign.end,
                    ),
                    // )
                  ],
                  // ),
                  // ),
                ),
              )
            : Padding(
                padding: EdgeInsets.only(
                    left: isMe
                        ? 0.0
                        : showUsername
                            ? 2.0.w
                            : 0.0,
                    right: isMe && showUsername ? 2.w : 0.0),
                child: Container(
                  constraints: BoxConstraints(minWidth: 6.w),
                  decoration: BoxDecoration(
                    color: isMe ? Colors.blue[50] : Colors.white,
                    borderRadius: BorderRadius.circular(1.5.w),
                  ),
                  child: Column(
                    crossAxisAlignment: isMe
                        ? CrossAxisAlignment.end
                        : CrossAxisAlignment.start,
                    children: [
                      // if (repliedUsername != null) // Check for nullability
                      repliedMessageWidget(
                        repliedMessage,
                        senderId,
                        isMe,
                        username,
                        index,
                        messages,
                        repliedUsername,
                        showUsername,
                      ),
                      Container(
                        padding: const EdgeInsets.all(8.0),
                        color: isMe ? Colors.blue[50] : Colors.white,
                        child: Container(
                          constraints: BoxConstraints(
                              maxWidth: 70.w), // Set your desired max width
                          child: Text(
                            message,
                            style:
                                Theme.of(context).textTheme.bodyLarge!.copyWith(
                                      color: kTextBlackColor,
                                      fontSize: 12.sp,
                                      fontWeight: FontWeight.normal,
                                    ),
                            textAlign: isMe ? TextAlign.left : TextAlign.left,
                            softWrap: true,
                            maxLines: 200, // Set the maximum number of lines
                            overflow:
                                TextOverflow.ellipsis, // Overflow behavior
                          ),
                        ),
                      ),
                      const SizedBox(height: 1.5),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Text(
                          time,
                          style: Theme.of(context)
                              .textTheme
                              .bodyLarge!
                              .copyWith(
                                color:
                                    isMe ? Colors.blue[500] : Colors.grey[500],
                                fontSize: 7.sp,
                                fontWeight: FontWeight.normal,
                              ),
                          textAlign: isMe ? TextAlign.right : TextAlign.left,
                        ),
                      )
                    ],
                  ),
                ),
              )
        : chatBubble;

    return isMe
        ? GestureDetector(
            onLongPressStart: (details) {
              final RenderBox overlay =
                  Overlay.of(context).context.findRenderObject() as RenderBox;
              final Offset tapPosition = details.globalPosition;
              final RelativeRect position = RelativeRect.fromRect(
                Rect.fromPoints(tapPosition, tapPosition),
                Offset.zero & overlay.size,
              );
              vibratePhone();
              _showPopupMenu(context, message, msgId, isMe, position);
            },
            child: SwipeTo(
              onLeftSwipe: (details) =>
                  _displayInputBottomSheet(message, username, isMe),
              iconOnLeftSwipe: Icons.reply,
              iconColor: kOtherColor,
              child: Column(
                crossAxisAlignment:
                    isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment:
                        isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                    children: [
                      showUsername
                          ? Padding(
                              padding: EdgeInsets.only(
                                  top: showUsername && repliedMessage != null
                                      ? 5.h
                                      : 0.0),
                              child: avatar)
                          : SizedBox(width: 13.3.w),
                      isMe
                          ? Padding(
                              padding: EdgeInsets.only(
                                  bottom: showUsername ? 0.5.h : 0.5.h,
                                  right: showUsername ? 2.w : 4.0.w),
                              child: messageContent,
                            )
                          : Padding(
                              padding: EdgeInsets.only(
                                  left: showUsername ? 0.0.w : 0.0,
                                  bottom: showUsername ? 0.5.h : 0.5.h),
                              child: messageContent,
                            ),
                      if (isMe) avatar,
                    ],
                  ),
                ],
              ),
            ),
          )
        : GestureDetector(
            onLongPressStart: (details) {
              final RenderBox overlay =
                  Overlay.of(context).context.findRenderObject() as RenderBox;
              final Offset tapPosition = details.globalPosition;
              final RelativeRect position = RelativeRect.fromRect(
                Rect.fromPoints(tapPosition, tapPosition),
                Offset.zero & overlay.size,
              );
              vibratePhone();
              _showPopupMenu(context, message, msgId, isMe, position);
            },
            child: SwipeTo(
              onRightSwipe: (details) =>
                  _displayInputBottomSheet(message, username, isMe),
              iconOnRightSwipe: Icons.reply,
              iconColor: kOtherColor,
              child: Column(
                crossAxisAlignment:
                    isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment:
                        isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
                    children: [
                      showUsername
                          ? Padding(
                              padding: EdgeInsets.only(
                                  top: showUsername && repliedMessage != null
                                      ? 5.h
                                      : 0.0),
                              child: avatar)
                          : SizedBox(width: 13.3.w),
                      isMe
                          ? Padding(
                              padding: EdgeInsets.only(
                                  bottom: showUsername ? 0.5.h : 0.5.h,
                                  right: showUsername ? 2.w : 4.0.w),
                              child: messageContent,
                            )
                          : Padding(
                              padding: EdgeInsets.only(
                                  left: showUsername ? 0.0.w : 0.0,
                                  bottom: showUsername ? 0.5.h : 0.5.h),
                              child: messageContent,
                            ),
                      if (isMe) avatar,
                    ],
                  ),
                ],
              ),
            ),
          );
  }

  Widget repliedMessageWidget(
    String repliedMessage,
    String senderId,
    bool isMe,
    String sentBy,
    int index,
    List messages,
    String? replyusername,
    bool showUsername,
  ) {
    return FutureBuilder<String?>(
      future: _getUsername(FirebaseAuth.instance.currentUser!.uid),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        } else {
          final sameuser = snapshot.data == replyusername;
          bool myusername = sameuser; // Default to false if null

          return Padding(
            padding: EdgeInsets.all(showUsername ? 0.0 : 1.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (replyusername != null)
                  Container(
                    color: Colors.white,
                    child: isMe
                        ? const SizedBox.shrink()
                        : showUsername
                            ? Text(
                                sentBy,
                                style: TextStyle(
                                  color: getUsernameColor(sentBy),
                                  fontSize: 10.sp,
                                ),
                                textAlign: TextAlign.left,
                              )
                            : null,
                  ),
                SizedBox(height: 0.5.h),
                Container(
                  constraints:
                      BoxConstraints(minWidth: showUsername ? 10.w : 16.w),
                  alignment: Alignment.centerLeft,
                  decoration: BoxDecoration(
                    color: Colors.grey[200],
                    borderRadius: BorderRadius.circular(1.5.w),
                  ),
                  padding: EdgeInsets.all(1.w),
                  child: Column(
                    children: [
                      Text(
                        myusername ? 'you' : replyusername!,
                        style: TextStyle(
                          color: myusername
                              ? Colors.green
                              : getUsernameColor(replyusername!),
                          fontSize: 10.sp,
                        ),
                      ),
                      SizedBox(height: 0.5.h),
                      Container(
                        constraints: BoxConstraints(maxWidth: 70.w),
                        child: Text(
                          repliedMessage,
                          style:
                              Theme.of(context).textTheme.bodyLarge!.copyWith(
                                    color: kTextBlackColor,
                                    fontSize: 12.sp,
                                    fontWeight: FontWeight.normal,
                                  ),
                          textAlign: TextAlign.left,
                          softWrap: true,
                          maxLines: 200,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }
      },
    );
  }

  void _displayInputBottomSheet(
    String? repliedMessage,
    String replyusername,
    bool isMe,
  ) {
    double bottomheight = 20.h;
    String replyText = '';

    showModalBottomSheet(
      // isScrollControlled: true,
      backgroundColor: Colors.transparent,
      context: context,
      builder: (context) {
        return Container(
          height: bottomheight,
          decoration: BoxDecoration(
            color: isMe ? Colors.blue[50] : Colors.white,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                spreadRadius: 1,
                blurRadius: 5,
                offset: const Offset(0, -1),
              ),
            ],
          ),
          child: ListView(
            padding: EdgeInsets.only(
              left: 10,
              right: 10,
              top: 10,
              bottom: MediaQuery.of(context).viewInsets.bottom + 10,
            ),
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 1.h),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: EdgeInsets.all(1.h),
                  width: double.infinity,
                  child: Text(
                    isMe ? 'you' : replyusername,
                    style: TextStyle(
                      fontSize: 12,
                      color: getUsernameColor(replyusername),
                    ),
                  ),
                ),
              ),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(color: Colors.grey[400]),
                child: RichText(
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  text: TextSpan(
                    text: repliedMessage ?? '',
                    style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                          color: Colors.black,
                          fontSize: 12,
                        ),
                  ),
                ),
              ),
              Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(
                      child: TextField(
                        onTap: () {
                          setState(() {
                            bottomheight = 55.h;
                          });
                        },
                        autofocus: false,
                        textInputAction: TextInputAction.newline,
                        maxLines: null,
                        textCapitalization: TextCapitalization.sentences,
                        onChanged: (value) {
                          replyText = value;
                        },
                        decoration: InputDecoration(
                          fillColor: Colors.grey[200],
                          labelText: 'Reply',
                          hintText: 'Enter reply here',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                        ),
                      ),
                    ),
                    CupertinoButton(
                      alignment: Alignment.center,
                      minSize: 0,
                      padding: EdgeInsets.all(2.w),
                      borderRadius: BorderRadius.circular(6.w),
                      color: Colors.green,
                      onPressed: () {
                        _handleSubmitted(
                          replyText,
                          repliedMessage: repliedMessage,
                          replyusername: replyusername,
                        );
                        Navigator.pop(context);
                      },
                      child: const Icon(
                        Icons.send,
                        color: CupertinoColors.white,
                      ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 1.h),
            ],
          ),
        );
      },
    );
  }

  Color getUsernameColor(String username) {
    final List<Color> acceptableColors = [
      Colors.blue,
      Colors.red,
      Colors.orange,
      Colors.purple,
      const Color.fromARGB(255, 197, 179, 15),
      Colors.teal,
      Colors.pink,
      Colors.indigo,
      Colors.cyan,
      // const Color.fromARGB(255, 210, 164, 27),
      Colors.deepOrange,
      const Color.fromARGB(255, 149, 165, 10),
    ];

    int hash = username.hashCode;
    Random random = Random(hash);
    return acceptableColors[random.nextInt(acceptableColors.length)];
  }

  void _showPopupMenu(BuildContext context, String message, String msgid,
      bool isMe, RelativeRect position) async {
    final result = isMe
        ? await showMenu(
            context: context,
            position: position,
            items: [
              PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    const Icon(
                      Icons.delete,
                      color: Color.fromARGB(255, 203, 186, 185),
                      size: 16.0,
                    ),
                    const SizedBox(width: 10.0),
                    Text(
                      'Delete',
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge!
                          .copyWith(color: Colors.red, fontSize: 13.0),
                    ),
                  ],
                ),
              ),
              // PopupMenuItem(
              //   value: 'edit',
              //   child: Row(
              //     children: [
              //       const Icon(
              //         Icons.edit,
              //         color: Colors.green,
              //         size: 16.0,
              //       ),
              //       const SizedBox(width: 10.0),
              //       Text(
              //         'Edit',
              //         style: Theme.of(context)
              //             .textTheme
              //             .bodyLarge!
              //             .copyWith(color: Colors.green, fontSize: 13.0),
              //       ),
              //     ],
              //   ),
              // ),
              PopupMenuItem(
                value: 'copy',
                child: Row(
                  children: [
                    Icon(
                      Icons.copy,
                      color: kPrimaryColor,
                      size: 16.0,
                    ),
                    const SizedBox(width: 10.0),
                    Text(
                      'Copy',
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge!
                          .copyWith(color: kPrimaryColor, fontSize: 13.0),
                    ),
                  ],
                ),
              ),
            ],
          )
        : await showMenu(
            context: context,
            position: position,
            items: [
              PopupMenuItem(
                value: 'copy',
                child: Row(
                  children: [
                    Icon(
                      Icons.copy,
                      color: kPrimaryColor,
                      size: 16.0,
                    ),
                    const SizedBox(width: 10.0),
                    Text(
                      'Copy',
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge!
                          .copyWith(color: kPrimaryColor, fontSize: 13.0),
                    ),
                  ],
                ),
              ),
            ],
          );

    if (result == 'delete') {
      _deleteMessage(message, msgid);
    } else if (result == 'edit') {
      _updateMessage(message);
    } else if (result == 'copy') {
      _copyToClipboard(message);
    }
    _messageFocusNode.unfocus();
  }

  void _deleteMessage(String messageId, String msgid) {
    showDialog(
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Are you sure?',
            style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                color: Colors.grey,
                fontSize: 17.sp,
                fontWeight: FontWeight.w600),
          ),
          actions: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                TextButton(
                    onPressed: () async {
                      try {
                        await _firestore
                            .collection('chats')
                            .doc(msgid)
                            .delete();
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Message Deleted'),
                            backgroundColor: Colors.red,
                          ),
                        );
                        Navigator.of(context).pop();
                      } catch (e) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Failed to delete message'),
                            backgroundColor: Colors.red,
                          ),
                        );
                        Navigator.of(context).pop();
                      }
                    },
                    child: Text("Delete for everyone",
                        style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                            color: kPrimaryColor,
                            fontSize: 15.sp,
                            fontWeight: FontWeight.w600))),
                TextButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Text(
                      "Cancel",
                      style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                          color: kPrimaryColor,
                          fontSize: 15.sp,
                          fontWeight: FontWeight.w600),
                    )),
              ],
            )
          ],
        );
      },
      context: context,
    );
  }

  void _updateMessage(String message) {}

  void _copyToClipboard(String message) {
    // Code to copy the message to the clipboard
    Clipboard.setData(ClipboardData(text: message));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Text coppied to clipboard'),
        animation: const AlwaysStoppedAnimation(1),
        backgroundColor: kPrimaryColor,
      ),
    );
  }

  void vibratePhone() async {
    try {
      await Vibration.hasVibrator();
      await Vibration.vibrate();
      await Future.delayed(const Duration(milliseconds: 20));
      await Vibration.cancel();
    } catch (error) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$error'),
          animation: const AlwaysStoppedAnimation(1),
          backgroundColor: kPrimaryColor,
        ),
      );
    }
  }
}

class RectangularClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    double borderRadius =
        10.0; // Adjust this value to control the size of the circular border

    // Move to top-left corner and draw the rounded corner
    path.moveTo(0, borderRadius);
    path.arcToPoint(
      Offset(0, borderRadius),
      radius: Radius.circular(borderRadius),
    );

    path.lineTo(0, size.height - borderRadius); // Line to bottom-left corner

    // Move to bottom-right corner and draw the rounded corner
    path.arcToPoint(
      Offset(borderRadius, size.height),
      radius: Radius.circular(borderRadius),
    );

    path.lineTo(
        size.width - borderRadius, size.height); // Line to bottom-right corner

    // Move to top-right corner and draw the rounded corner
    path.arcToPoint(
      Offset(size.width, size.height - borderRadius),
      radius: Radius.circular(borderRadius),
    );

    path.lineTo(size.width, borderRadius); // Line to top-right corner

    // Move back to top-left corner to complete the rectangular path
    path.arcToPoint(
      Offset(borderRadius, 0),
      radius: Radius.circular(borderRadius),
    );

    path.close(); // Close the path to form a complete shape

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}

class CircularBorderClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    Path path = Path();
    double radius = size.height / 2; // Half of the height to make it circular

    path.moveTo(radius, 0); // Move to top-left corner of the circle
    path.lineTo(
        size.width - radius, 0); // Line to top-right corner of the circle
    path.arcToPoint(
      Offset(size.width - radius, size.height),
      radius: Radius.circular(radius),
    ); // Top-right curve
    path.lineTo(
        radius, size.height); // Line to bottom-left corner of the circle
    path.arcToPoint(
      Offset(radius, 0),
      radius: Radius.circular(radius),
    ); // Bottom-left curve
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return false;
  }
}

// Usage:
