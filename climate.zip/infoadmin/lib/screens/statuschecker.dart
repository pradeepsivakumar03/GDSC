import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:infoadmin/data/controllers/weather_controller.dart';
import 'package:infoadmin/data/models/weather.dart';
import 'package:infoadmin/screens/location_screen.dart';
import 'package:infoadmin/screens/login_screen.dart';
import 'package:infoadmin/screens/verifyemail.dart';
import 'package:lottie/lottie.dart';
import 'package:sizer/sizer.dart';

class StateChecker extends StatefulWidget {
  final Weather weatherData;
  const StateChecker({Key? key, required this.weatherData}) : super(key: key);

  @override
  _StateCheckerState createState() => _StateCheckerState();
}

class _StateCheckerState extends State<StateChecker> {
  WeatherController weatherController = WeatherController();
  // Weather? weather;
  // void getWeatherData() async {
  //   // if (widget.fromPage == 'location') {
  //   // weather = await weatherController.getWeatherByLocation();
  //   // } else if (widget.fromPage == 'city') {
  //   // if (widget.cityName != null) {
  //   weather = await weatherController.getWeatherByCity("Coimbatore");
  //   // } else {
  //   // weather = await weatherController.getWeatherByLocation();
  //   // }
  // }

  @override
  void initState() {
    super.initState();
    // getWeatherData();
  }

  // Future<void> _initializeFirebaseApp() async {
  //   await Firebase.initializeApp();
  // }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<User?>(
      future: _checkUserStatus(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          if (snapshot.hasError || snapshot.data == null) {
            return LoginPage(
              weatherData: widget.weatherData,
            );
          } else {
            final user = snapshot.data;
            if (user != null) {
              if (!user.emailVerified) {
                return VerifyEmail(weatherData: widget.weatherData);
              } else {
                return LocationScreen(
                  weatherData: widget.weatherData,
                );
              }
            } else {
              return LoginPage(weatherData: widget.weatherData);
            }
          }
        } else {
          return Scaffold(
              backgroundColor: Colors.white,
              body: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // SizedBox(
                  //     // height: 40.h,
                  //     // width: 80.h,
                  //     child:
                  //         Lottie.asset('assets/lottie/schecker_loading.json')),
                  Center(
                    child: Text(
                      "Loading...",
                      style: Theme.of(context)
                          .textTheme
                          .bodyLarge!
                          .copyWith(color: Colors.green, fontSize: 18.sp),
                    ),
                  )
                ],
              ));
        }
      },
    );
  }

  Future<User?> _checkUserStatus() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      final isDisabled = await _isUserDisabled(user.uid);
      if (!isDisabled) {
        return user;
      }
    }
    return null;
  }

  Future<bool> _isUserDisabled(String uid) async {
    CollectionReference usersCollection =
        FirebaseFirestore.instance.collection('users');

    try {
      var snapshot = await usersCollection.doc(uid).get();
      return snapshot.exists
          ? (snapshot.data() as Map<String, dynamic>)['disabled'] ?? false
          : false;
    } catch (error) {
      return false; // Return false if there's an error to be cautious.
    }
  }
}
