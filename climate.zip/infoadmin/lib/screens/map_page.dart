// import 'package:collegeapk/constants.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CampusMap extends StatefulWidget {
  const CampusMap({super.key});

  @override
  _CampusMapState createState() => _CampusMapState();
}

class _CampusMapState extends State<CampusMap> {
  GoogleMapController? mapController;
  static const CameraPosition initialCameraPosition = CameraPosition(
      // tilt: 100,
      target: LatLng(
        11.127111972,
        77.0388986,
      ),
      zoom: 16.0,
      bearing: 180);
  @override
  void initState() {
    super.initState();
    mapController;
  }

  @override
  void dispose() {
    super.dispose();
    mapController!.dispose();
  }

  final Set<Marker> _markers = {
    const Marker(
      markerId: MarkerId('cafe'),
      position: LatLng(11.127983, 77.038606),
      infoWindow: InfoWindow(
        title: 'Cafeteria',
        snippet: '',
      ),
    ),
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade200,
      appBar: AppBar(
        title: const Text(
          'Map',
          style: TextStyle(color: Colors.white),
        ),
      ),
      // floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
      // floatingActionButton: FloatingActionButton.extended(
      //   backgroundColor: Colors.black,
      //   onPressed: () {
      //     mapController?.animateCamera(
      //         CameraUpdate.newCameraPosition(initialCameraPosition));
      //   },
      //   label: Text(
      //     'Go to',
      //     style: Theme.of(context)
      //         .textTheme
      //         .headlineLarge!
      //         .copyWith(color: Colors.white, fontSize: 10.sp),
      //   ),
      //   icon: Icon(
      //     Icons.location_on,
      //     color: Colors.white,
      //     size: 3.h,
      //   ),
      // ),
      body: GoogleMap(
        buildingsEnabled: true,
        compassEnabled: true,
        indoorViewEnabled: true,
        mapToolbarEnabled: true,
        // trafficEnabled: true,
        markers: _markers,
        mapType: MapType.satellite,
        initialCameraPosition: initialCameraPosition,
        onMapCreated: (GoogleMapController controller) {
          mapController = controller;
        },
      ),
    );
  }
}
