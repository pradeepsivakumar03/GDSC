import 'package:flutter/material.dart';
import 'package:infoadmin/data/models/weather.dart';
import 'package:infoadmin/screens/location_screen.dart';

class SkillsPreferencesScreen extends StatefulWidget {
  final Weather weather;
  const SkillsPreferencesScreen({super.key, required this.weather});

  @override
  _SkillsPreferencesScreenState createState() =>
      _SkillsPreferencesScreenState();
}

class _SkillsPreferencesScreenState extends State<SkillsPreferencesScreen> {
  List<String> selectedSkills = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Skills and Preferences'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Select your skills and preferences:',
              style: TextStyle(fontSize: 18.0),
            ),
            const SizedBox(height: 20.0),
            Expanded(
              child: ListView(
                children: List.generate(
                  skillsList.length,
                  (index) {
                    final skill = skillsList[index];
                    return ListTile(
                      title: Text(skill),
                      trailing: selectedSkills.contains(skill)
                          ? const Icon(Icons.check_circle, color: Colors.green)
                          : null,
                      onTap: () {
                        setState(() {
                          if (selectedSkills.contains(skill)) {
                            selectedSkills.remove(skill);
                          } else {
                            selectedSkills.add(skill);
                          }
                        });
                      },
                    );
                  },
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (builder) =>
                        LocationScreen(weatherData: widget.weather)));
              },
              child: const Text('Done'),
            ),
          ],
        ),
      ),
    );
  }
}

List<String> skillsList = [
  'Medical',
  'Rescue',
  'First Aid',
  'Communication',
  'Logistics',
  'Other',
];
