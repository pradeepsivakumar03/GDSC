import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:infoadmin/data/models/weather.dart';
import 'package:infoadmin/screens/verifyemail.dart';
import 'package:infoadmin/screens/volenteer/skills_screen.dart';
import 'package:sizer/sizer.dart';

class VolunteerRegistrationScreen extends StatefulWidget {
  final Weather weather;
  const VolunteerRegistrationScreen({super.key, required this.weather});

  @override
  _VolunteerRegistrationScreenState createState() =>
      _VolunteerRegistrationScreenState();
}

class _VolunteerRegistrationScreenState
    extends State<VolunteerRegistrationScreen> {
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Volunteer Registration'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('User Registration'),
            TextFormField(
              controller: fullNameController,
              decoration: const InputDecoration(labelText: 'Full Name'),
            ),
            TextFormField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextFormField(
              controller: passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            ElevatedButton(
              onPressed: () {
                // Implement user registration logic
                // You may want to validate the input fields before proceeding
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VolunteerSkillsScreen(
                      weather: widget.weather,
                    ),
                  ),
                );
              },
              child: const Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}
