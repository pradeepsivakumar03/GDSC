import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CommunicationChannelScreen extends StatefulWidget {
  const CommunicationChannelScreen({super.key});

  @override
  _CommunicationChannelScreenState createState() =>
      _CommunicationChannelScreenState();
}

class _CommunicationChannelScreenState
    extends State<CommunicationChannelScreen> {
  final TextEditingController messageController = TextEditingController();
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  late CollectionReference messages;

  @override
  void initState() {
    super.initState();
    messages = firestore.collection('your_collection_name');

    messages.snapshots().listen((QuerySnapshot snapshot) {
      snapshot.docChanges.forEach((DocumentChange change) {
        print('New message: ${change.doc.data()}');
        // Implement logic to display the received message in the chat UI
      });
    });
  }

  void sendMessage(String message) {
    messages.add({
      'text': message,
      'timestamp': FieldValue.serverTimestamp(),
    });
    messageController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Communication Channel'),
      ),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder(
              stream: messages.orderBy('timestamp').snapshots(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError) {
                  return Text('Error: ${snapshot.error}');
                }

                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                }

                return ListView(
                  children:
                      snapshot.data!.docs.map((DocumentSnapshot document) {
                    return ListTile(
                      title: Text(document['text']),
                    );
                  }).toList(),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: messageController,
                    decoration: InputDecoration(
                      hintText: 'Type your message...',
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.send),
                  onPressed: () {
                    sendMessage(messageController.text);
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
