import 'package:flutter/material.dart';

import '../communication_channel.dart';

class MapIntegrationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Map Integration'),
      ),
      body: Column(
        children: [
          const Text('Map view with highlighted disaster-prone areas.'),
          // Implement map integration UI here
          Expanded(
            child: Container(
              // Replace this with your map widget or integration
              color: Colors.blueGrey, // Placeholder color
              child: const Center(
                child: Text(
                  'Map Widget Placeholder',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              // Implement map pinpoints logic
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ChatScreen(),
                ),
              );
            },
            child: const Text('Next'),
          ),
        ],
      ),
    );
  }
}
