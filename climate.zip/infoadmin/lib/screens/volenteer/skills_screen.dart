import 'package:flutter/material.dart';
import 'package:infoadmin/data/models/weather.dart';
import 'package:infoadmin/screens/field_preference.dart';

class VolunteerSkillsScreen extends StatefulWidget {
  final Weather weather;
  const VolunteerSkillsScreen({super.key, required this.weather});

  @override
  _VolunteerSkillsScreenState createState() => _VolunteerSkillsScreenState();
}

class _VolunteerSkillsScreenState extends State<VolunteerSkillsScreen> {
  final TextEditingController skillsController = TextEditingController();
  final TextEditingController preferencesController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Skills and Preferences'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Text('Skills and Preferences'),
            // TextFormField(
            //   controller: skillsController,
            //   decoration: InputDecoration(labelText: 'Skills'),
            // ),
            TextFormField(
              controller: preferencesController,
              decoration: const InputDecoration(labelText: 'Preferred Areas'),
            ),
            const SizedBox(
              height: 20,
            ),
            ElevatedButton(
              onPressed: () {
                // Implement skills and preferences logic
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SkillsPreferencesScreen(
                      weather: widget.weather,
                    ),
                  ),
                );
              },
              child: const Text('Continue'),
            ),
          ],
        ),
      ),
    );
  }
}
