import 'dart:async';

import 'package:flutter/material.dart';

import 'mapintrigation.dart';

class LiveDisasterFeedScreen extends StatefulWidget {
  const LiveDisasterFeedScreen({super.key});

  @override
  State<LiveDisasterFeedScreen> createState() => _LiveDisasterFeedScreenState();
}

class _LiveDisasterFeedScreenState extends State<LiveDisasterFeedScreen> {
  // Example: This is just a placeholder for a real-time stream.
  final StreamController<String> _liveDisasterStreamController =
      StreamController<String>.broadcast();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Live Disaster Feed'),
      ),
      body: Column(
        children: [
          Text('Real-time feed displaying current disasters and emergencies.'),
          // Use StreamBuilder to listen to the live disaster stream
          StreamBuilder<String>(
            stream: _liveDisasterStreamController.stream,
            builder: (context, snapshot) {
              // Display the live disaster information in real-time
              if (snapshot.hasData) {
                return Text(snapshot.data!);
              } else {
                return Text('No live disasters at the moment.');
              }
            },
          ),
          ElevatedButton(
            onPressed: () {
              // Implement filtering options logic
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => MapIntegrationScreen(),
                ),
              );
            },
            child: Text('Next'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _liveDisasterStreamController.close();
    super.dispose();
  }
}
