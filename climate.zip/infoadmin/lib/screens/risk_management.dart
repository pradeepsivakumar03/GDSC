import 'package:flutter/material.dart';

class RiskAssessmentScreen extends StatefulWidget {
  @override
  _RiskAssessmentScreenState createState() => _RiskAssessmentScreenState();
}

class _RiskAssessmentScreenState extends State<RiskAssessmentScreen> {
  Map<String, dynamic> userResponses = {};

  List<Map<String, dynamic>> questions = [
    {
      'question': 'Do you live in an area prone to floods?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Is your region susceptible to wildfires?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Does your area experience earthquakes?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Are hurricanes or cyclones common in your region?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Do you live in a coastal area prone to tsunamis?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Does your region face extreme heatwaves?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Is your area at risk of landslides?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Are you in an area prone to avalanches?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Does your region experience severe droughts?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Is your area prone to volcanic eruptions?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Do you live in an urban area susceptible to pollution?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Are you in a region at risk of dam failures?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Does your area experience severe thunderstorms?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Is your region prone to blizzards or heavy snowfall?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Do you live in a region susceptible to hailstorms?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Does your area have a high risk of forest fires?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Are you in an area prone to mudslides?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Does your region have a history of industrial accidents?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Is your area prone to power outages?',
      'options': ['Yes', 'No'],
    },
    {
      'question': 'Do you live in a region vulnerable to disease outbreaks?',
      'options': ['Yes', 'No'],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Risk Assessment'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Answer the following questions to assess your risk:',
              style: TextStyle(fontSize: 18.0),
            ),
            const SizedBox(height: 20.0),
            for (int i = 0; i < questions.length; i++) _buildQuestionWidget(i),
            const SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: () {
                _generateResilienceReport();
              },
              child: const Text('Generate Resilience Report'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuestionWidget(int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          questions[index]['question'],
          style: const TextStyle(fontSize: 16.0),
        ),
        const SizedBox(height: 10.0),
        for (String option in questions[index]['options'])
          RadioListTile(
            title: Text(option),
            value: option,
            groupValue: userResponses['q$index'],
            onChanged: (value) {
              setState(() {
                userResponses['q$index'] = value;
              });
            },
          ),
        const Divider(),
      ],
    );
  }

  void _generateResilienceReport() {
    int totalRiskPoints = 0;

    for (int i = 0; i < questions.length; i++) {
      String response = userResponses['q$i'];
      // You can customize the scoring logic based on your needs
      if (response == 'Yes') {
        totalRiskPoints += 10; // Assign points for 'Yes' answers
      }
    }

    // You can further customize the resilience report based on the total risk points
    String resilienceReport = '';

    if (totalRiskPoints < 20) {
      resilienceReport =
          'Low risk. Your region has relatively low susceptibility to climate-related hazards.';
    } else if (totalRiskPoints < 40) {
      resilienceReport =
          'Moderate risk. Consider taking precautionary measures for potential hazards.';
    } else {
      resilienceReport =
          'High risk. Immediate action and preparedness are advised to mitigate potential hazards.';
    }

    // Display the resilience report
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Resilience Report'),
          content: Text(resilienceReport),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
