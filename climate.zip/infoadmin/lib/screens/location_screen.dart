import 'package:flutter/material.dart';
import 'package:infoadmin/data/models/location.dart';
import 'package:infoadmin/screens/communication_channel.dart';
import 'package:infoadmin/screens/field_preference.dart';
import 'package:infoadmin/screens/liv_dis_feed.dart';
import 'package:infoadmin/screens/map_page.dart';
import 'package:infoadmin/screens/request_page.dart';
import 'package:infoadmin/screens/risk_management.dart';
import 'package:infoadmin/screens/screens.dart';
import 'package:infoadmin/screens/virtual.dart';
import 'package:infoadmin/screens/volenteer/registration.dart';
import '../data/controllers/weather_controller.dart';
import '../data/models/weather.dart';
import '../utilities/constants.dart';
import '../widgets/weather_content.dart';
import 'carbon_footprint.dart';
import 'disaster_prediction.dart';

class LocationScreen extends StatefulWidget {
  final Weather weatherData;

  const LocationScreen({super.key, required this.weatherData});

  @override
  _LocationScreenState createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  WeatherController weatherController = WeatherController();
  late Weather weather;
  Location currentLocation = Location();

  // void getWeatherData() async {
  //   // if (currentLocation.latitude != null && currentLocation.longitude != null) {
  //   //   weather = await weatherController.getWeatherByLocation();
  //   // } else {
  //   // if (widget.cityName != null) {
  //   weather = await weatherController.getWeatherByCity('Coimbatore');
  //   // }
  //   //   } else {
  //   //     weather = await weatherController.getWeatherByLocation();
  //   //   }
  //   // }
  //   updateUI(weather);
  // }

  @override
  void initState() {
    // getWeatherData();
    super.initState();
    updateUI(widget.weatherData);
  }

  void updateUI(Weather weatherData) {
    setState(() {
      weather = weatherData;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        centerTitle: true,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () {
              Scaffold.of(context).openDrawer();
            },
          ),
        ),
        title: Text(
          weather.city,
          style: kLocationTextStyle,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.my_location),
            onPressed: () async {
              weather = await weatherController.getWeatherByLocation();
              updateUI(weather);
              // Navigator.push(
              //   context,
              //   MaterialPageRoute(
              //     builder: (context) => const CityScreen(),
              //   ),
              // );
            },
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () async {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const CityScreen(),
                ),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue.shade200,
              ),
              child: const Column(
                children: [
                  CircleAvatar(
                    backgroundColor: Colors.black,
                    radius: 40,
                    child: Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 45,
                    ),
                  ),
                  SizedBox(height: 15),
                  Text(
                    'pradeepsivakumar03@gmail.com',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              title: const Text('Risk Assesment'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RiskAssessmentScreen(),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('Carbon FootPrint'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CarbonFootprintCalculator(),
                  ),
                );
              },
            ),
            // ListTile(
            //   title: const Text('VR simulation'),
            //   onTap: () {
            //     Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (context) => VRSimulationScreen(),
            //       ),
            //     );
            //   },
            // ),
            ListTile(
              title: const Text('Disaster Prediction'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const DisasterPredictionScreen(),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('Map'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const CampusMap(),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('Communication vol'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ChatScreen(),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('LiveDisaster'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => LiveDisasterFeedScreen(),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('Volunteer Registration'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => VolunteerRegistrationScreen(
                      weather: widget.weatherData,
                    ),
                  ),
                );
              },
            ),
            ListTile(
              title: const Text('RequestPage'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const RequestPage(),
                  ),
                );
              },
            )
          ],
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: constraints.maxHeight,
              ),
              child: IntrinsicHeight(
                child: WeatherContent(
                  weatherImage: weatherController.getWeatherImage(
                    weather.condition.toInt(),
                  ),
                  temperature: weather.temperature,
                  wind: weather.wind,
                  humidity: weather.humidity,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
