import 'package:flutter/material.dart';

class AddDisasterItemScreen extends StatefulWidget {
  @override
  _AddDisasterItemScreenState createState() => _AddDisasterItemScreenState();
}

class _AddDisasterItemScreenState extends State<AddDisasterItemScreen> {
  TextEditingController titleController = TextEditingController();
  TextEditingController descriptionController = TextEditingController();
  TextEditingController locationController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Disaster Item'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: titleController,
              decoration: InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
            ),
            TextField(
              controller: locationController,
              decoration: InputDecoration(labelText: 'Location'),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                _addDisasterItem();
              },
              child: Text('Add'),
            ),
          ],
        ),
      ),
    );
  }

  void _addDisasterItem() {
    // Get values from controllers
    String title = titleController.text;
    String description = descriptionController.text;
    String location = locationController.text;

    // Validate inputs
    if (title.isEmpty || description.isEmpty || location.isEmpty) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Please fill all fields.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text('OK'),
              ),
            ],
          );
        },
      );
      return;
    }

    // Add new disaster item and navigate back
    Navigator.pop(context, {
      'title': title,
      'description': description,
      'location': location,
    });
  }
}
