import 'package:flutter/material.dart';
import 'package:infoadmin/screens/add_disaster.dart';

class LiveDisasterFeedScreen extends StatefulWidget {
  @override
  _LiveDisasterFeedScreenState createState() => _LiveDisasterFeedScreenState();
}

class _LiveDisasterFeedScreenState extends State<LiveDisasterFeedScreen> {
  List<DisasterItem> disasterItems = [
    DisasterItem(
      title: 'Flood',
      description: 'Migrate to high level place',
      location: 'XYZ Street, ABC City', // Example location
    ),
    DisasterItem(
      title: 'Earthquake',
      description: 'Take cover under sturdy furniture',
      location: '123 Avenue, DEF Town', // Example location
    ),
    // Add more instances of DisasterItem with different data
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Live Disaster Feed'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16.0),
              child: ListView.builder(
                itemCount: disasterItems.length,
                itemBuilder: (context, index) {
                  return AnimatedDisasterCard(
                    disasterItem: disasterItems[index],
                    // You can pass additional parameters for animation customization
                  );
                },
              ),
            ),
          ),
          const SizedBox(height: 16.0),
          ElevatedButton(
            onPressed: () async {
              final Map<String, String?>? result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AddDisasterItemScreen(),
                ),
              );

              if (result != null) {
                setState(() {
                  disasterItems.add(
                    DisasterItem(
                      title: result['title']!,
                      description: result['description']!,
                      location: result['location']!,
                    ),
                  );
                });
              }
            },
            child: const Text('Add Disaster Item'),
          ),
        ],
      ),
    );
  }
}

class AnimatedDisasterCard extends StatefulWidget {
  final DisasterItem disasterItem;

  AnimatedDisasterCard({required this.disasterItem});

  @override
  _AnimatedDisasterCardState createState() => _AnimatedDisasterCardState();
}

class _AnimatedDisasterCardState extends State<AnimatedDisasterCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(seconds: 1),
      vsync: this,
    );

    _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    // Trigger the animation when the widget is added to the tree
    _animationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _opacityAnimation,
      child: Card(
        elevation: 4.0,
        margin: const EdgeInsets.symmetric(vertical: 8.0),
        child: ListTile(
          title: Text(widget.disasterItem.title),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(widget.disasterItem.description),
              Text('Location: ${widget.disasterItem.location}'),
              // Add more UI elements based on your data model
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}

class DisasterItem {
  final String title;
  final String description;
  final String location;
  // Add more fields as needed

  DisasterItem({
    required this.title,
    required this.description,
    required this.location,
    // Initialize additional fields here
  });
}
