import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

class DisasterPredictionScreen extends StatefulWidget {
  const DisasterPredictionScreen({Key? key}) : super(key: key);

  @override
  _DisasterPredictionScreenState createState() =>
      _DisasterPredictionScreenState();
}

class _DisasterPredictionScreenState extends State<DisasterPredictionScreen> {
  // Placeholder for the prediction level
  int predictionLevel = 0;
  final apiKey = '7d0c88f017454f055766e3e6c21eea2d';
  bool _showProgress = true;

  @override
  void initState() {
    fetchPredictionLevel();
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        _showProgress = false;
      });
    });
  }

  // Fetch prediction level from the API
  Future<void> fetchPredictionLevel() async {
    final response = await http.get(
      Uri.parse(
          'https://api.openweathermap.org/data/2.5/weather?q=Coimbatore&appid=$apiKey'), // Replace 'Coimbatore' with the desired city name
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      print('API Response: $data');

      final main = data['main'];
      final temperature = main['temp'];

      setState(() {
        predictionLevel = temperature.round();
      });
    } else {
      // Handle error
      print(
          'Failed to fetch prediction level. Status code: ${response.statusCode}');
      print('Response body: ${response.body}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Disaster Prediction'),
      ),
      body: Center(
        child: _showProgress
            ? CircularProgressIndicator()
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Prediction Level: 1',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 20),
                  DisasterPredictionIndicator(predictionLevel: predictionLevel),
                  const SizedBox(height: 20),
                  const Text(
                    'Risk Level: Low Risk',
                    style: TextStyle(fontSize: 18),
                  ),
                ],
              ),
      ),
    );
  }

  // Map prediction levels to risk levels
  String getRiskLevel(int level) {
    switch (level) {
      case 1:
        return 'Low Risk';
      case 2:
        return 'Moderate Risk';
      case 3:
        return 'High Risk';
      case 4:
        return 'Very High Risk';
      case 5:
        return 'Critical Risk';
      default:
        return 'Unknown Risk';
    }
  }
}

class DisasterPredictionIndicator extends StatelessWidget {
  final int predictionLevel;

  const DisasterPredictionIndicator({Key? key, required this.predictionLevel})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    Color indicatorColor = getIndicatorColor(1);

    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: indicatorColor,
      ),
      child: Center(
        child: Text(
          1.toString(),
          style: const TextStyle(
            fontSize: 24,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Color getIndicatorColor(int level) {
    if (level <= 2) {
      return Colors.green;
    } else if (level <= 4) {
      return Colors.orange;
    } else {
      return Colors.red;
    }
  }
}
