import 'package:flutter/material.dart';

class Disaster {
  String address;
  String location;
  List<Need> needs;

  Disaster({
    required this.address,
    required this.location,
    required this.needs,
  });
}

class Need {
  String item;
  int totalQuantity;
  int currentQuantity;

  Need({
    required this.item,
    required this.totalQuantity,
    required this.currentQuantity,
  });
}

class DisasterList extends StatelessWidget {
  final List<Disaster> disasters;

  const DisasterList(this.disasters, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: ListView.builder(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: disasters.length,
        itemBuilder: (context, index) {
          return DisasterCard(disaster: disasters[index]);
        },
      ),
    );
  }
}

class DisasterCard extends StatelessWidget {
  final Disaster disaster;

  const DisasterCard({Key? key, required this.disaster}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.grey,
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text(
                  'Address:  ',
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                Text(
                  disaster.address,
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Location:  ',
                  style: TextStyle(fontWeight: FontWeight.w500),
                ),
                Flexible(
                  child: Text(
                    disaster.location,
                    softWrap: true,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('Needs:'),
            NeedList(needs: disaster.needs),
          ],
        ),
      ),
    );
  }
}

class NeedList extends StatelessWidget {
  final List<Need> needs;

  const NeedList({Key? key, required this.needs}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: needs.map((need) => NeedItem(need: need)).toList(),
    );
  }
}

class NeedItem extends StatefulWidget {
  final Need need;

  const NeedItem({Key? key, required this.need}) : super(key: key);

  @override
  _NeedItemState createState() => _NeedItemState();
}

class _NeedItemState extends State<NeedItem> {
  TextEditingController quantityText = TextEditingController();

  @override
  void initState() {
    quantityText.text = widget.need.currentQuantity.toString();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        '${widget.need.item} - ${widget.need.currentQuantity}/${widget.need.totalQuantity}',
        style: const TextStyle(fontSize: 12),
      ),
      subtitle: Column(
        children: [
          Row(
            children: [
              SizedBox(
                width: 100, // Adjust the width as per your preference
                child: LinearProgressIndicator(
                  value: (widget.need.totalQuantity != 0)
                      ? widget.need.currentQuantity / widget.need.totalQuantity
                      : 0.0,
                ),
              ),
              const SizedBox(width: 16),
              Row(
                children: [
                  widget.need.currentQuantity == 0
                      ? IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.remove,
                            color: Colors.grey.shade400,
                            size: 20,
                          ),
                        )
                      : IconButton(
                          icon: const Icon(
                            Icons.remove,
                            size: 20,
                            color: Colors.white,
                          ),
                          onPressed: () {
                            setState(() {
                              widget.need.currentQuantity =
                                  (widget.need.currentQuantity - 1)
                                      .clamp(0, widget.need.totalQuantity);
                            });
                          },
                        ),
                  Text('${widget.need.currentQuantity}'),
                  widget.need.currentQuantity == widget.need.totalQuantity
                      ? IconButton(
                          onPressed: () {},
                          icon: Icon(
                            Icons.add,
                            color: Colors.grey.shade400,
                            size: 20,
                          ),
                        )
                      : IconButton(
                          icon: const Icon(
                            Icons.add,
                            size: 20,
                            color: Colors.white,
                          ),
                          onPressed: () {
                            setState(() {
                              widget.need.currentQuantity =
                                  (widget.need.currentQuantity + 1)
                                      .clamp(0, widget.need.totalQuantity);
                            });
                          },
                        ),
                ],
              ),
            ],
          ),
          ElevatedButton(
            onPressed: () {
              _showDonationSuccessDialog(context);
            },
            child: const Text('Donate'),
          ),
        ],
      ),
    );
  }

  void _showDonationSuccessDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Donation Successful'),
          content: Text('You have successfully donated ${widget.need.item}.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}

class RequestPage extends StatefulWidget {
  const RequestPage({Key? key}) : super(key: key);

  @override
  _RequestPageState createState() => _RequestPageState();
}

class _RequestPageState extends State<RequestPage> {
  final List<Disaster> disasters = [
    Disaster(
      address: "123 Main Street",
      location: "Latitude: 40.7128, Longitude: -74.0060",
      needs: [
        Need(item: "Water Bottles", totalQuantity: 100, currentQuantity: 0),
        Need(item: "Food Packets", totalQuantity: 200, currentQuantity: 0),
      ],
    ),
    Disaster(
      address: "456 Elm Street",
      location: "Latitude: 39.7392, Longitude: -104.9903",
      needs: [
        Need(item: "Blankets", totalQuantity: 50, currentQuantity: 0),
        Need(item: "First Aid Kits", totalQuantity: 100, currentQuantity: 0),
      ],
    ),
    // Add more dummy data as needed
  ];

  final TextEditingController itemNameController = TextEditingController();
  final TextEditingController totalQuantityController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Requests'),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Request New Items',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextFormField(
                    controller: itemNameController,
                    decoration: const InputDecoration(labelText: 'Item'),
                  ),
                  TextFormField(
                    controller: totalQuantityController,
                    decoration:
                        const InputDecoration(labelText: 'Total Quantity'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Get the values entered in the text fields
                      String itemName = itemNameController.text;
                      int totalQuantity =
                          int.tryParse(totalQuantityController.text) ?? 0;

                      // Add a new disaster to the list
                      disasters.add(
                        Disaster(
                          address: "New Address",
                          location: "New Location",
                          needs: [
                            Need(
                                item: itemName,
                                totalQuantity: totalQuantity,
                                currentQuantity: 0),
                          ],
                        ),
                      );

                      // Clear the text fields
                      itemNameController.clear();
                      totalQuantityController.clear();

                      // Update the UI
                      setState(() {});

                      // Show a message indicating the request has been submitted
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Request Submitted'),
                        ),
                      );
                    },
                    child: const Text('Submit Request'),
                  ),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: Text(
                'Existing Requests',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            DisasterList(disasters),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    itemNameController.dispose();
    totalQuantityController.dispose();
    super.dispose();
  }
}
