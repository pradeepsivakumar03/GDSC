import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:infoadmin/firebase_options.dart';
import 'package:infoadmin/screens/screens.dart';
import 'package:infoadmin/utilities/constants.dart';
import 'package:sizer/sizer.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(Sizer(builder: (context, orientation, device) {
    return const MyApp();
  }));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle.light,
    );

    return MaterialApp(
        title: 'Flutter Clima',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(
          primaryColor: kPrimaryDarkColor,
          hintColor: kTealColor,
          scaffoldBackgroundColor: kPrimaryDarkColor,
        ),
        home: const LoadingScreen(
          fromPage: 'city',
          cityName: 'Coimbatore',
        ));
  }
}
